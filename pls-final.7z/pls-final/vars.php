<?php
	$musicDir = "music/";

	//FORMATS ACCEPTÉS :
	//	- mp3
	//	- ogg
?>